package br.com.letscode.funcionarios;

import java.util.Objects;

public class Funcionario extends Object{

    String nomeFuncionario;
    String cpfFuncionario;
    double salarioFuncionario;

    public double calcularSalario (int diasTrabalhados){

        double salarioCalculado = diasTrabalhados * ( salarioFuncionario/30);

        return salarioCalculado;
    }


    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Funcionario{");
        sb.append("nomeFuncionario='").append(nomeFuncionario).append('\'');
        sb.append(", cpfFuncionario='").append(cpfFuncionario).append('\'');
        sb.append(", salarioFuncionario=").append(salarioFuncionario);
        sb.append('}');
        return sb.toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Funcionario that = (Funcionario) o;
        return Double.compare(that.salarioFuncionario, salarioFuncionario) == 0 && nomeFuncionario.equals(that.nomeFuncionario) && cpfFuncionario.equals(that.cpfFuncionario);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nomeFuncionario, cpfFuncionario, salarioFuncionario);
    }
}
