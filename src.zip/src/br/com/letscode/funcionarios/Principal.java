package br.com.letscode.funcionarios;

import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {

        Funcionario Funcionario = new Funcionario();

        Funcionario.nomeFuncionario = "Joao da Silva";
        Funcionario.cpfFuncionario = "33305876819";
        Funcionario.salarioFuncionario = 2000.00;

        Scanner sc = new Scanner (System.in);
        System.out.println("Digite a quantidade de dias trabalhados: ");
        int diasTrabalhados = sc.nextInt();

        double salario = Funcionario.calcularSalario(diasTrabalhados);

        System.out.printf("O seu salário a receber é de: R$ %.2f  \n" , salario);

        System.out.println("Objeto funcionário: " + Funcionario.toString());

        System.out.println("HashCode funcionário: " + Funcionario.hashCode());


    }
}
